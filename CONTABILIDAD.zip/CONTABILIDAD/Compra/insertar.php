<?php
include("Conexion.php");
$con=conectar();

$Fecha=$_POST['Fecha'];
$Proveedor=$_POST['Proveedor'];
$Ref=$_POST['Ref'];
$FactNum=$_POST['FactNum'];
$Cond=$_POST['Cond'];
$Compras=$_POST['Compras'];
$ITMBS=$_POST['ITMBS'];
$Ctsxpg=$_POST['Ctsxpg'];

$sql="INSERT INTO diarioc VALUES('$Fecha','$Proveedor','$Ref','$FactNum', '$Cond', '$Compras', '$ITMBS', '$Ctsxpg')";
$query= mysqli_query($con,$sql);
 if ($con->query($sql) === true){
    echo "<font color='#145A32'>Compra Guardando...Grabada</font>";
    }else {
        die("ERROR: VERIFIQUE " . $con->error);
    }
if($query){
    Header("Location: Libro.php");
    
}else {
}
?>