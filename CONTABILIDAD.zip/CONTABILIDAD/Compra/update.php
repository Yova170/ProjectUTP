<?php

include("Conexion.php");
$con=conectar();

$Fecha=$_POST['Fecha'];
$Proveedor=$_POST['Proveedor'];
$Ref=$_POST['Ref'];
$FactNum=$_POST['FactNum'];
$Compras=$_POST['Compras'];
$ITMBS=$_POST['ITMBS'];
$Ctasxpg=$_POST['Ctasxpg'];

$sql="UPDATE diarioc SET  Fecha='$Fecha',Proveedor='$Proveedor',Ref='$Ref', FactNum='$FactNum', Compras='$Compras', ITMBS='$ITMBS', Ctasxpg='Ctasxpg' WHERE FactNum='$FactNum'";
$query=mysqli_query($con,$sql);

    if($query){
        Header("Location: Libro.php");
    }
?>, 