<?php

include("Conexion.php");
$con=conectar();

$FactNum=$_GET['FactNum'];

$sql="DELETE FROM diarioc  WHERE bdcontbilidad='$FactNum'";
$query=mysqli_query($con,$sql);

    if($query){
        Header("Location: Libro.php");
    }
?>
