<?php 
    include("conexion.php");
    $con=conectar();

    $sql="SELECT *  FROM bdcontabilidad";
    $query=mysqli_query($con,$sql);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>bdcontabilidad - INGRESOS</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
        
    </head>
    <body>
        <?php
        require 'Header.php'
        ?>
            <div class="container mt-5">
                    <div class="row"> 
                        
                        <div class="col-md-3">
                            <h1>Ingrese datos</h1>
                                <form action="insertar.php" method="POST">

                                    <input type="Date" class="form-control mb-3" name="Fecha"  placeholder="fecha de generacion">
                                    <input type="text" class="form-control mb-3" name="Comprador"             placeholder="Comprador de la compra">
                                    <input type="text" class="form-control mb-3" name="Ref"         placeholder="referencia de la compra">
                                    <input type="text" class="form-control mb-3" name="NumFact"       placeholder="numero de la factura">
                                    <input type="text" class="form-control mb-3" name="Cond"  placeholder="Cond de la compra">
                                    <input type="text" class="form-control mb-3" name="Venta"             placeholder="valor de la compra">
                                    <input type="submit" class="btn btn-primary">
                                </form>
                        </div>

                        <div class="col-md-8">
                        <h1>Diario Venta</h1><!--Diario Venta-->
                            <table class="table" >
                                <thead class="table-success table-striped" >
                                    <tr>
                                        <th>N</th>
                                        <th>Fecha</th>
                                        <th>Comprador</th>
                                        <th>Referencia</th>
                                        <th>N� Factura</th>
                                        <th>CCond</th>
                                        <th>Compra</th>
                                        <th>ITBMS</th>
                                        <th>Cts x Pagar</th>
                                        <th> </th>
                                    </tr>
                                </thead>

                                <tbody>
                                        <?php
                                            while($row=mysqli_fetch_array($query)){
                                               
                                        ?>
                                            <tr>
                                                <th><?php  echo $clin1 ?></th>
                                                <th><?php  echo $row['Fecha']?></th>
                                                <th><?php  echo $row['Comprador']?></th>
                                                <th><?php  echo $row['Ref']?></th>
                                                <th><?php  echo $row['NumFact']?></th>
                                                <th><?php  echo $row['Cond']?></th>
                                                <th><?php  echo $row['Venta']?></th>   
                                                <th><?php  echo $row['ITBMS']?></th>
                                                <th><?php  echo $row['Ctsxcb']?></th>   
                                                <th><div class="btn-group">
                                                  <button type="button" class="btn btn-default dropdown-toggle"
                                                          data-toggle="dropdown"> EDITAR <span class="caret"></span>
                                                  </button>
                                                  <ul class="dropdown-menu" role="menu">
                                                    <li><a href="actualizar.php?id=<?php echo $row['Venta'] ?>">Monto</a></li>
                                                    <li><a href="actualizar.php?id=<?php echo $row['Comprador'] ?>">Comprador</a></li>
                                                    <li><a href="actualizar.php?id=<?php echo $row['Cond'] ?>">Cond</a></li>
                                                    <li class="divider"></li>
                                                    <li><a href="delete.php?id=<?php echo $row['Ref'] ?>">Eliminar</a></li>
                                                  </ul>
                                                </div></th>                                        
                                            </tr>
                                        <?php 
                                         $clin1 += 1; // Incremento de Contador de Registros
                                                $impuesto = $Ctsxcb * 0.07; 
	                                            $ITBMS = Round ($segsoc, 2);// 7%
	                                            $Compra = $Ctsxcb + $ITBMS; 
	                                            $Ctsxcb = Round (Compra, 2); // compraneta
                                            }
                                        ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="col-md-8">
                        <br>
                        <h3>Diario General</h3> <!--Diario General-->
                            <table class="table" >
                                <thead class="table-success table-striped" >
                                    <tr>
                                        <th>FECHA</th>
                                        <th>DETALLE</th>
                                        <th>REFERENCIA</th>
                                        <th>DEBITO</th>
                                        <th>CREDITO</th>
                                    </tr>
                                </thead>

                                <tbody>
                                        <?php
                                            while($row=mysqli_fetch_array($query)){
                                        ?>
                                            <tr>
                                                <th><?php  echo $row['Fecha']?></th>
                                                <th><?php  echo $row['Comprador']?></th>
                                                <th><?php  echo $row['Ref']?></th>
                                                <th><?php  echo $row['Num.Fact']?></th>
                                                <th><?php  echo $row['Num.Fact']?></th>                                           
                                            </tr>
                                        <?php 
                                            }
                                        ?>
                                </tbody>
                            </table>
                        </div>
                    </div>  
                     <div class="col-md-8">
                     <br>
                        <h3>Mayores</h3> <!--Mayores-->
                            <table class="table" >
                                <thead class="table-success table-striped" >
                                    <tr>
                                        <th>Fecha</th>
                                        <th>Mayor G. Venta</th>
                                        <th>Mayor G. ITBMS</th>
                                        <th>Mayor G. Cuentas por Pagar</th>
                                    </tr>
                                </thead>

                                <tbody>
                                        <?php
                                            while($row=mysqli_fetch_array($query)){
                                        ?>
                                            <tr>
                                                <th><?php  echo $row['Fecha']?></th>
                                                <th>
                                                
                                                </th>
                                                <th>
                                                
                                                </th>
                                                <th>
                                                
                                                </th>    
                                            </tr>
                                        <?php 
                                            }
                                        ?>
                                </tbody>
                            </table>
                        </div>
            </div>
    </body>
</html>