<?php
include("Conexion.php");
$con=conectar();

$Fecha=$_POST['Fecha'];
$Comprador=$_POST['Comprador'];
$Ref=$_POST['Ref'];
$FactNum=$_POST['FactNum'];
$Venta=$_POST['Venta'];
$ITBMS=$_POST['ITBMS'];
$Ctsxcb=$_POST['Ctsxcb'];

$sql="INSERT INTO diariov VALUES('$Fecha','$Comprador','$Ref','$FactNum','$Venta', '$ITBMS', '$Ctsxcb')";
$query= mysqli_query($con,$sql);
 if ($con->query($sql) === true){
    echo "<font color='#145A32'>Compra Guardad...Grabada</font>";
    }else {
        die("ERROR...VERIFIQUE..." . $con->error);
    }
if($query){
    Header("Location: Libro.php");
    
}else {
}
?>