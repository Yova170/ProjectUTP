<?php

include("Conexion.php");
$con=conectar();

$Debito=$_GET['Debito'];

$sql="DELETE FROM diarioe  WHERE bdcontbilidad='$Debito'";
$query=mysqli_query($con,$sql);

    if($query){
        Header("Location: Libro.php");
    }
?>
