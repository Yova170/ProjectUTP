<?php 
    include("conexion.php");
    $con=conectar();

    $sql="SELECT *  FROM bdcontabilidad";
    $query=mysqli_query($con,$sql);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>bdcontabilidad - INGRESOS</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link hDoc="css/style.css" rel="stylesheet">
        <link hDoc="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
        
    </head>
    <body>
        <?php
        require 'Header.php'
        ?>
            <div class="container mt-5">
                    <div class="row"> 
                        
                        <div class="col-md-3">
                            <h1>Ingrese datos</h1>
                                <form action="insertar.php" method="POST">

                                    <input type="Date" class="form-control mb-3" name="Fecha"  placeholder="fecha de generacion">
                                    <input type="text" class="form-control mb-3" name="Detalle"             placeholder="Detalle de la compra">
                                    <input type="text" class="form-control mb-3" name="Doc"         placeholder="Docerencia de la compra">
                                    <input type="text" class="form-control mb-3" name="Debito"       placeholder="numero de la factura">
                                    <input type="text" class="form-control mb-3" name="Compras"  placeholder="Compras de la compra">
                                    <input type="text" class="form-control mb-3" name="Credito"             placeholder="valor de la compra">
                                    <input type="submit" class="btn btn-primary">
                                </form>
                        </div>

                        <div class="col-md-8">
                        <h1>Diario Credito</h1><!--Diario Credito-->
                            <table class="table" >
                                <thead class="table-success table-striped" >
                                    <tr>
                                        <th>N</th>
                                        <th>Fecha</th>
                                        <th>Detalle</th>
                                        <th>Doc</th>
                                        <th>Debito</th>
                                        <th>Credito</th>
                                        <th>Compras</th>
                                        <th>ITBMS</th>
                                        <th>Cts x Pagar</th>
                                        <th> </th>
                                    </tr>
                                </thead>

                                <tbody>
                                        <?php
                                            while($row=mysqli_fetch_array($query)){
                                               
                                        ?>
                                            <tr>
                                                <th><?php  echo $clin1 ?></th>
                                                <th><?php  echo $row['Fecha']?></th>
                                                <th><?php  echo $row['Detalle']?></th>
                                                <th><?php  echo $row['Doc']?></th>
                                                <th><?php  echo $row['Debito']?></th>
                                                <th><?php  echo $row['Compras']?></th>
                                                <th><?php  echo $row['Credito']?></th>   
                                                <th><?php  echo $row['ITBMS']?></th>
                                                <th><?php  echo $row['Ctasxpg']?></th>   
                                                <th><div class="btn-group">
                                                  <button type="button" class="btn btn-default dropdown-toggle"
                                                          data-toggle="dropdown"> EDITAR <span class="caret"></span>
                                                  </button>
                                                  <ul class="dropdown-menu" role="menu">
                                                    <li><a hDoc="actualizar.php?id=<?php echo $row['Credito'] ?>">Monto</a></li>
                                                    <li><a hDoc="actualizar.php?id=<?php echo $row['Detalle'] ?>">Detalle</a></li>
                                                    <li><a hDoc="actualizar.php?id=<?php echo $row['Compras'] ?>">Compras</a></li>
                                                    <li class="divider"></li>
                                                    <li><a hDoc="delete.php?id=<?php echo $row['Doc'] ?>">Eliminar</a></li>
                                                  </ul>
                                                </div></th>                                        
                                            </tr>
                                        <?php 
                                         $clin1 += 1; // Incremento de Contador de Registros
                                                $impuesto = $Ctsxpg * 0.07; 
	                                            $ITBMS = Round ($segsoc, 2);// 7%
	                                            $Compra = $Ctsxpg + $ITBMS; 
	                                            $Ctasxpg = Round (Compra, 2); // compraneta
                                            }
                                        ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="col-md-8">
                        <br>
                        <h3>Diario General</h3> <!--Diario General-->
                            <table class="table" >
                                <thead class="table-success table-striped" >
                                    <tr>
                                        <th>FECHA</th>
                                        <th>DETALLE</th>
                                        <th>DocERENCIA</th>
                                        <th>DEBITO</th>
                                        <th>CREDITO</th>
                                    </tr>
                                </thead>

                                <tbody>
                                        <?php
                                            while($row=mysqli_fetch_array($query)){
                                        ?>
                                            <tr>
                                                <th><?php  echo $row['Fecha']?></th>
                                                <th><?php  echo $row['Detalle']?></th>
                                                <th><?php  echo $row['Doc']?></th>
                                                <th><?php  echo $row['Num.Fact']?></th>
                                                <th><?php  echo $row['Num.Fact']?></th>                                           
                                            </tr>
                                        <?php 
                                            }
                                        ?>
                                </tbody>
                            </table>
                        </div>
                    </div>  
                     <div class="col-md-8">
                     <br>
                        <h3>Mayores</h3> <!--Mayores-->
                            <table class="table" >
                                <thead class="table-success table-striped" >
                                    <tr>
                                        <th>Fecha</th>
                                        <th>Mayor G. Credito</th>
                                        <th>Mayor G. ITBMS</th>
                                        <th>Mayor G. Cuentas por Pagar</th>
                                    </tr>
                                </thead>

                                <tbody>
                                        <?php
                                            while($row=mysqli_fetch_array($query)){
                                        ?>
                                            <tr>
                                                <th><?php  echo $row['Fecha']?></th>
                                                <th>
                                                
                                                </th>
                                                <th>
                                                
                                                </th>
                                                <th>
                                                
                                                </th>    
                                            </tr>
                                        <?php 
                                            }
                                        ?>
                                </tbody>
                            </table>
                        </div>
            </div>
    </body>
</html>