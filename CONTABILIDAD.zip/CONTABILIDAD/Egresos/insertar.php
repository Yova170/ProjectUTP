<?php
include("Conexion.php");
$con=conectar();

$Fecha=$_POST['Fecha'];
$Detalle=$_POST['Detalle'];
$Doc=$_POST['Doc'];
$Debito=$_POST['Debito'];
$Credito=$_POST['Credito'];
$ITBMS=$_POST['ITBMS'];
$Ctasxpg=$_POST['Ctasxpg'];

$sql="INSERT INTO diarioe VALUES('$Fecha','$Detalle','$Doc','$Debito','$Credito', '$ITBMS', '$Ctasxpg')";
$query= mysqli_query($con,$sql);
 if ($con->query($sql) === true){
    echo "<font color='#145A32'>Compra Guardad...Grabada</font>";
    }else {
        die("ERROR...VERIFIQUE..." . $con->error);
    }
if($query){
    Header("Location: Libro.php");
    
}else {
}
?>