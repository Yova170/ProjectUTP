<?php 
    include("Conexion.php");
    $con=conectar();

    $sql="SELECT *  FROM diarioc";
    $query=mysqli_query($con,$sql);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>inventario - INGRESOS</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
        
    </head>
    <body>
        
            <div class="container mt-5">
                    <div class="row"> 
                    <div class="col-md-3">
                            <h1>Ingrese datos</h1>
                                <form action="insertar.php" method="POST">

                                    <input type="Date" class="form-control mb-3" name="Fecha"  placeholder="fecha de generacion">
                                    <input type="text" class="form-control mb-3" name="idProveedor"             placeholder="idProveedor de la compra">
                                    <input type="int" class="form-control mb-3" name="Ref"         placeholder="referencia de la compra">
                                    <input type="int" class="form-control mb-3" name="idFactura"       placeholder="numero de la factura">
                                    <input type="int" class="form-control mb-3" name="Condicion"  placeholder="Condicion de la compra">
                                    <input type="float" class="form-control mb-3" name="Venta"             placeholder="valor de la compra">
                                    <input type="submit" class="btn btn-primary">
                                </form>
                        </div>
                        <div class="col-md-8">
                        <h1>Diario Compras </h1><!--Diario Compras-->
                            <table class="table" >
                                <thead class="table-success table-striped" >
                                    <tr>
                                        <th>N</th>
                                        <th>Fecha</th>
                                        <th>idProveedor</th>
                                        <th>Referencia</th>
                                        <th>N� Factura</th>
                                        <th>Condicion</th>
                                        <th>Compra</th>
                                        <th>ITBMSDebito</th>
                                        <th>CtsCredito</th>
                                        <th> </th>
                                    </tr>
                                </thead>
                                <?php 
                                $Impuesto=0;
                                $ITBMSDebitoT=0;
                                $Credito=0;
                                $ComprasDebito=0;
                                $ITBMSDebito=0;
                                            $Impuesto = $ComprasDebito * 0.07; 
                                            $ITBMSDebitoT = Round ($Impuesto, 2);// 7%
                                            $Credito = $ComprasDebito + $ITBMSDebito; 
                                            $CtsCredito = Round (ComprasDebito, 2); // compraneta
                                ?>
                                <tbody>
                                        <?php
                                        $clin=0; 
                                        while($row=mysqli_fetch_array($query)){
                                        $clin += 1; // Incremento de Contador de Registros

                                        ?>
                                            <tr>
                                                <th><?php  echo $clin ?></th>
                                                <th><?php  echo $row['Fecha']?></th>
                                                <th><?php  echo $row['idProveedor']?></th>
                                                <th><?php  echo $row['Ref']?></th>
                                                <th><?php  echo $row['idFactura']?></th>
                                                <th><?php  echo $row['Condicion']?></th>
                                                <th><?php  echo $row['ComprasDebito']?></th>
                                                <th><?php  echo $row['ITBMSDebito']?></th>
                                                <th><?php  echo $row['CtsCredito']?></th>   
                                                <th><div class="btn-group">
                                                  <button type="button" class="btn btn-default dropdown-toggle"
                                                          data-toggle="dropdown"> EDITAR <span class="caret"></span>
                                                  </button>
                                                  <ul class="dropdown-menu" role="menu">
                                                    <li><a href="actualizar.php?id=<?php echo $row['idFactura'] ?>">Monto</a></li>
                                                    <li class="divider"></li>
                                                    <li><a href="delete.php?id=<?php echo $row['Ref'] ?>">Eliminar</a></li>
                                                  </ul>
                                                </div></th>                                        
                                            </tr>
                                        <?php 
                                            
                                            }
                                        ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="col-md-8">
                        <br>
                        <h3>Diario General</h3> <!--Diario General-->
                            <table class="table" >
                                <thead class="table-success table-striped" >
                                    <tr>
                                        <th>FECHA</th>
                                        <th>DETALLE</th>
                                        <th>REFERENCIA</th>
                                        <th>DEBITO</th>
                                        <th>CREDITO</th>
                                    </tr>
                                </thead>

                                <tbody>
                                        <?php
                                            while($row=mysqli_fetch_array($query)){
                                        ?>
                                            <tr>
                                                <th><?php  echo $row['Fecha']?></th>
                                                <th><?php  echo $row['idProveedor']?></th>
                                                <th><?php  echo $row['Ref']?></th>
                                                <th><?php  echo $row['Num.Fact']?></th>
                                                <th><?php  echo $row['Num.Fact']?></th>                                           
                                            </tr>
                                        <?php 
                                            }
                                        ?>
                                </tbody>
                            </table>
                        </div>
                    </div>  
                     <div class="col-md-8">
                     <br>
                        <h3>Mayores</h3> <!--Mayores-->
                            <table class="table" >
                                <thead class="table-success table-striped" >
                                    <tr>
                                        <th>Fecha</th>
                                        <th>Mayor G. ComprasDebito</th>
                                        <th>Mayor G. ITBMSDebito</th>
                                        <th>Mayor G. Cuentas por Pagar</th>
                                    </tr>
                                </thead>

                                <tbody>
                                        <?php
                                            while($row=mysqli_fetch_array($query)){
                                        ?>
                                            <tr>
                                                <th><?php  echo $row['Fecha']?></th>
                                                <th>
                                                
                                                </th>
                                                <th>
                                                
                                                </th>
                                                <th>
                                                
                                                </th>    
                                            </tr>
                                        <?php 
                                            }
                                        ?>
                                </tbody>
                            </table>
                        </div>
            </div>
    </body>
</html>