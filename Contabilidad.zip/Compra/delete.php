<?php

include("Conexion.php");
$con=conectar();

$idFactura=$_GET['idFactura'];

$sql="DELETE FROM diarioc  WHERE bdcontbilidad='$idFactura'";
$query=mysqli_query($con,$sql);

    if($query){
        Header("Location: Libro.php");
    }
?>
