<?php
include("Conexion.php");
$con=conectar();

$Fecha=$_POST['Fecha'];
$idProveedor=$_POST['idProveedor'];
$Ref=$_POST['Ref'];
$idFactura=$_POST['idFactura'];
$Condicion=$_POST['Condicion'];
$ComprasDebito=$_POST['ComprasDebito'];
$ITBMSDebito=$_POST['ITBMSDebito'];
$CtsCredito=$_POST['CtsCredito'];

$sql="INSERT INTO diarioc VALUES('$Fecha','$idProveedor','$Ref','$idFactura', '$Condicion', '$ComprasDebito', '$ITBMSDebito', '$CtsCredito')";
$query= mysqli_query($con,$sql);
 if ($con->query($sql) === true){
    echo "<font color='#145A32'>Compra Guardando...Grabada</font>";
    }else {
        die("ERROR: VERIFIQUE " . $con->error);
    }
if($query){
    Header("Location: Libro.php");
    
}else {
}
?>