<?php

include("Conexion.php");
$con=conectar();

$Fecha=$_POST['Fecha'];
$idProveedor=$_POST['idProveedor'];
$Ref=$_POST['Ref'];
$idFactura=$_POST['idFactura'];
$ComprasDebito=$_POST['ComprasDebito'];
$ITBMSDebito=$_POST['ITBMSDebito'];
$Ctasxpg=$_POST['Ctasxpg'];

$sql="UPDATE diarioc SET  Fecha='$Fecha',idProveedor='$idProveedor',Ref='$Ref', idFactura='$idFactura', ComprasDebito='$ComprasDebito', ITBMSDebito='$ITBMSDebito', Ctasxpg='Ctasxpg' WHERE idFactura='$idFactura'";
$query=mysqli_query($con,$sql);

    if($query){
        Header("Location: Libro.php");
    }
?>, 