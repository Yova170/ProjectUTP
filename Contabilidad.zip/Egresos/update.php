<?php

include("Conexion.php");
$con=conectar();

$Fecha=$_POST['Fecha'];
$Detalle=$_POST['Detalle'];
$Doc=$_POST['Doc'];
$Debito=$_POST['Debito'];
$Credito=$_POST['Credito'];
$ITBMS=$_POST['ITBMS'];
$Ctasxpg=$_POST['Ctasxpg'];

$sql="UPDATE diarioe SET  Fecha='$Fecha',Detalle='$Detalle',Doc='$Doc', Debito='$Debito', Credito='$Credito', ITBMS='$ITBMS', Ctasxpg='Ctasxpg' WHERE cod_estudiante='$Doc'";
$query=mysqli_query($con,$sql);

    if($query){
        Header("Location: Libro.php");
    }
?>, 