<?php

include("Conexion.php");
$con=conectar();

$Fecha=$_POST['Fecha'];
$Doc=$_POST['Doc'];
$Detalle=$_POST['Detalle'];
$Debito=$_POST['Debito'];
$Banco=$_POST['Banco'];
$ITBMS=$_POST['ITBMS'];
$Ctsxcb=$_POST['Ctsxcb'];

$sql="UPDATE diarioi SET  Fecha='$Fecha',Doc='$Doc',Detalle='$Detalle', Debito='$Debito', Banco='$Banco', ITBMS='$ITBMS', Ctsxcb='Ctsxcb' WHERE cod_estudiante='$Detalle'";
$query=mysqli_query($con,$sql);

    if($query){
        Header("Location: Libro.php");
    }
?>, 