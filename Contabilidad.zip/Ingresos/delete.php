<?php

include("Conexion.php");
$con=conectar();

$Doc=$_GET['Doc'];

$sql="DELETE FROM diarioi  WHERE bdcontbilidad='$Doc'";
$query=mysqli_query($con,$sql);

    if($query){
        Header("Location: Libro.php");
    }
?>
