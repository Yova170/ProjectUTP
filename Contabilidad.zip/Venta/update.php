<?php

include("Conexion.php");
$con=conectar();

$Fecha=$_POST['Fecha'];
$Comprador=$_POST['Comprador'];
$Ref=$_POST['Ref'];
$idFactura=$_POST['idFactura'];
$Venta=$_POST['Venta'];
$ITBMS=$_POST['ITBMS'];
$Ctsxcb=$_POST['Ctsxcb'];

$sql="UPDATE diariov SET  Fecha='$Fecha',Comprador='$Comprador',Ref='$Ref', idFactura='$idFactura', Venta='$Venta', ITBMS='$ITBMS', Ctsxcb='Ctsxcb' WHERE cod_estudiante='$Ref'";
$query=mysqli_query($con,$sql);

    if($query){
        Header("Location: Libro.php");
    }
?>, 