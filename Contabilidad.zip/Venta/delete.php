<?php

include("Conexion.php");
$con=conectar();

$idFactura=$_GET['idFactura'];

$sql="DELETE FROM diariov  WHERE bdcontbilidad='$idFactura'";
$query=mysqli_query($con,$sql);

    if($query){
        Header("Location: Libro.php");
    }
?>
