<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Libros Contables</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link hDetalle="css/style.css" rel="stylesheet">
        <link hDetalle="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
        
    </head>
    <body>
        <center>
<h1>Libros Contables: </h1>
<div class="col-md-8">
<br>
                                                  <button type="button">
                                                  <a href="Venta/Libro.php"><h2>Diario de Ventas</h2></a>
                                                  </button>
                                                  <br><br>
                                                  <button type="button" >
                                                  <a href="Compra/Libro.php"><h2>Diario de Compras</h2></a>
                                                  </button>
                                                  <br><br>
                                                  <button type="button">
                                                  <a href="Egresos/Libro.php"><h2>Diario de Egresos</h2></a>
                                                  </button>
                                                  <br><br>
                                                  <button type="button">
                                                  <a href="Ingresos/Libro.php"><h2>Diario de Ingresos</h2></a>
                                                  </button>
                                                  <br>
</center>
    </body>
</html>